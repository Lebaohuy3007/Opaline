// swiftlint:disable:this file_name
import Foundation

enum HTTPHeader {
    static let contentType        = "Content-Type"
    static let accept             = "Accept"
    static let acceptLanguage     = "Accept-Language"
    static let acceptEncoding     = "Accept-Encoding"
    static let authorization      = "Authorization"
    static let userAgent          = "User-Agent"
    static let origin             = "Origin"
    static let referer            = "Referer"
    static let range              = "Range"

    /// YouTube-specific headers
    static let xOrigin = "X-Origin"
    static let xYoutubeClientName    = "X-Youtube-Client-Name"
    static let xYoutubeClientVersion = "X-Youtube-Client-Version"
    static let xGoogVisitorId     = "X-Goog-Visitor-Id"
    static let xGoogApiKey        = "x-goog-api-key"
    static let xUserAgent         = "x-user-agent"
}

// MARK: - HTTP header value constants

enum HTTPHeaderValue {
    static let contentTypeJSON    = "application/json"
    static let contentTypeOctet   = "application/octet-stream"
    static let acceptLanguageEN   = "en-US,en;q=0.9"
}

// MARK: - User-Agent strings

enum UserAgent {
    /// Desktop Chrome 140 — used for WEB client Innertube requests.
    static let chromeDesktop = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "AppleWebKit/537.36 (KHTML, like Gecko)",
        "Chrome/140.0.0.0 Safari/537.36,gzip(gfe)"
    ].joined(separator: " ")

    /// Older Chrome — used for signed URL playback requests.
    static let chromeDesktopPlayback = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
        "AppleWebKit/537.36 (KHTML, like Gecko)",
        "Chrome/139.0.0.0 Safari/537.36"
    ].joined(separator: " ")

    /// Chrome on macOS — used for web-client direct playback.
    static let chromeMac = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "AppleWebKit/537.36 (KHTML, like Gecko)",
        "Chrome/122.0.0.0 Safari/537.36"
    ].joined(separator: " ")

    /// The phone client, used only for the muxed 360p stream.
    static let androidPhone =
        "com.google.android.youtube/21.26.364 (Linux; U; Android 11) gzip"

    /// Safari on visionOS — the VISIONOS client's own agent.
    static let visionOS = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3)",
        "AppleWebKit/605.1.15 (KHTML, like Gecko)",
        "Version/26.0 Safari/605.1.15"
    ].joined(separator: " ")

    /// Cobalt (TV embedded browser) — used for the OAuth device flow.
    static let cobaltTV =
        "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version"

    /// The living-room browser YouTube's own TV app runs in, matching the
    /// `7.2026…` client version it reports. googlevideo refuses TV media asked
    /// for under `Cobalt/Version` — the placeholder above — while a signed-in
    /// session under this one is served (checked side by side, 2026-08-18).
    static let webOSTV = [
        "Mozilla/5.0 (Web0S; Linux/SmartTV)",
        "AppleWebKit/537.36 (KHTML, like Gecko)",
        "Chrome/85.0.4183.93/7.1 Safari/537.36 WebAppManager"
    ].joined(separator: " ")

    /// Cobalt on Fire TV — a real TVHTML5 user agent, used for TV playback.
    /// SmartTube settled on this one after Chrome-engine UAs got throttled.
    static let cobaltFireTV = [
        "Mozilla/5.0 (Linux armeabi-v7a; Android 7.1.2; Fire OS 6.0)",
        "Cobalt/22.lts.3.306369-gold (unlike Gecko)",
        "v8/8.8.278.8-jit gles Starboard/13,",
        "Amazon_ATV_mediatek8695_2019/NS6294 (Amazon, AFTMM, Wireless)",
        "com.amazon.firetv.youtube/22.3.r2.v66.0"
    ].joined(separator: " ")

    /// Mobile Safari on iPhone — used for the anonymous MWEB playback client.
    static let mobileSafari = [
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X)",
        "AppleWebKit/605.1.15 (KHTML, like Gecko)",
        "Version/17.5 Mobile/15E148 Safari/604.1"
    ].joined(separator: " ")

    /// Safari on macOS — used for WKWebView po_token generation.
    static let safariMac = [
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)",
        "AppleWebKit/605.1.15 (KHTML, like Gecko)",
        "Version/18.0 Safari/605.1.15"
    ].joined(separator: " ")

    /// YouTube iOS app — used for IOS client Innertube requests (captions).
    static let iosYouTube =
        "com.google.ios.youtube/20.10.4"
            + " (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)"
}

// MARK: - YouTube API credentials

enum YouTubeCredentials {
    /// Public YouTube TV API key (embedded in TV client pages, not secret).
    static let tvApiKey = "AIzaSyDyT5W0Jh49F30Pqqtyfdf7pDLFKLJoAnw"
}
