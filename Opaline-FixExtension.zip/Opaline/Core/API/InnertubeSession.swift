import Foundation

// MARK: - InnertubeSession
//
// Holds all immutable configuration for the Innertube API client.
// Mirrors the responsibility of YouTube.js Session — separating
// client config from request execution.
//
// InnertubeClient should depend on InnertubeSession for all config lookups,
// not store raw strings or inline context dictionaries.

final class InnertubeSession {
    private static let visitorDataTTL: TimeInterval = 24 * 60 * 60

    // MARK: - Endpoints

    let baseURL: String = AppURLs.YouTube.innertube

    // MARK: - Client contexts

    var webContext: [String: Any] { InnertubeContexts.web }
    var tvContext: [String: Any] { InnertubeContexts.tv }
    var androidContext: [String: Any] { InnertubeContexts.android }

    // MARK: - Mutable session state
    //
    // These are populated after session initialisation from the page or player response.
    // nil = not yet known (requests still work; YouTube returns defaults).

    /// Visitor data from the initial page response (`visitorData` field).
    /// Persisted with a TTL so the first video of a session doesn't pay the
    /// ~1s watch-page preflight; the cookies it pairs with live in
    /// `HTTPCookieStorage`, which iOS persists across launches as well.
    var visitorData: String? {
        get {
            let defaults = UserDefaults.standard
            guard
                let value = defaults.string(
                    forKey: UserDefaultsKeys.Innertube.visitorData
                ),
                let stamp = defaults.object(
                    forKey: UserDefaultsKeys.Innertube.visitorDataDate
                ) as? Date,
                Date().timeIntervalSince(stamp) < Self.visitorDataTTL
            else {
                return nil
            }
            return value
        }
        set {
            let defaults = UserDefaults.standard
            defaults.set(newValue, forKey: UserDefaultsKeys.Innertube.visitorData)
            defaults.set(Date(), forKey: UserDefaultsKeys.Innertube.visitorDataDate)
        }
    }

    /// Player signature timestamp — required for signed stream URLs.
    /// Extracted from the player JS or `/player` response.
    var signatureTimestamp: Int?

    // MARK: - URL helpers

    /// Builds a fully-qualified Innertube API URL for the given endpoint path.
    /// - Parameter endpoint: An `InnertubeEndpoint` path, e.g. `InnertubeEndpoint.browse`.
    func url(for endpoint: String) -> String {
        baseURL + endpoint
    }

    // MARK: - Context mutations
    //
    // Returns a copy of the given context with optional overrides applied.
    // Keeps base contexts immutable; callers never mutate the shared dicts.

    /// Returns a TV context, optionally appending a continuation token or browseId.
    func tvBrowseBody(
        browseId: String? = nil,
        continuation: String? = nil,
        params: String? = nil
    ) -> [String: Any] {
        var body = tvContext
        if let id = browseId { body[JSONKey.browseId] = id }
        if let cont = continuation { body[JSONKey.continuation] = cont }
        if let param = params { body[JSONKey.params] = param }
        return body
    }

    /// Returns a web context, optionally appending a continuation token or browseId.
    func webBrowseBody(
        browseId: String? = nil,
        continuation: String? = nil,
        params: String? = nil
    ) -> [String: Any] {
        var body = webContext
        if let id = browseId { body[JSONKey.browseId] = id }
        if let cont = continuation { body[JSONKey.continuation] = cont }
        if let param = params { body[JSONKey.params] = param }
        return body
    }
}

// MARK: - Visitor identity

extension InnertubeSession {
    /// Bumped every time the visitor identity is dropped. Callers that kicked
    /// off work under the old identity compare this before and after to tell a
    /// "the identity was replaced, try again" failure from a real one.
    private(set) static var identityGeneration = 0

    /// Drops the persisted visitor identity and its paired visitor cookies so
    /// the next request mints a fresh one. Called when /player answers the bot
    /// check, and when googlevideo throttles the identity — either way it would
    /// otherwise stay cached for the full TTL and keep every source failing.
    /// Account cookies are left untouched: minting is fully anonymous.
    static func invalidateVisitorIdentity(reason: String = "bot check") {
        identityGeneration += 1
        let defaults = UserDefaults.standard
        defaults.removeObject(forKey: UserDefaultsKeys.Innertube.visitorData)
        defaults.removeObject(forKey: UserDefaultsKeys.Innertube.visitorDataDate)
        guard let base = URL(string: AppURLs.YouTube.base) else {
            return
        }
        HTTPCookieStorage.shared.cookies(for: base)?
            .filter { $0.name.hasPrefix("VISITOR_") }
            .forEach(HTTPCookieStorage.shared.deleteCookie)
        AppLog.innertube("visitor identity invalidated after \(reason)")
    }
}
