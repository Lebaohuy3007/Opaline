import AVFoundation
import AVKit
import UIKit

protocol VideoPlayerViewDelegate: AnyObject {
    func videoPlayerViewDidTapSettings(
        _ playerView: VideoPlayerView
    )
    func videoPlayerViewDidTapFullscreen(
        _ playerView: VideoPlayerView
    )
    func videoPlayerViewDidTapAudioOnly(
        _ playerView: VideoPlayerView
    )
}

final class VideoPlayerView: UIView {
    // MARK: - Public Properties

    weak var delegate: VideoPlayerViewDelegate?

    var isFullscreen: Bool = false {
        didSet {
            updateFullscreenIcon()
            if !isFullscreen {
                setZoom(1, animated: false)
                zoomIsAuto = false
            }
        }
    }

    var onTimeUpdate: ((Double) -> Void)?
    var onSkipTapped: (() -> Void)?
    var onNeedsFreshPlayer: (() -> Void)?
    var onPrevious: (() -> Void)?
    var onNext: (() -> Void)?

    /// End screen: the centre controls become Previous / Replay / Next.
    /// Set when a video ends without anything playing after it; cleared as
    /// soon as playback resumes (any path — button, seek bar, remote).
    var isAtEnd = false {
        didSet {
            updateCenterIcons()
        }
    }

    /// Greyed out until the session has something to go back to. Next
    /// needs no such flag — there is always a suggestion to play.
    var hasPreviousVideo = false

    var player: AVPlayer?

    // MARK: - Layers

    let playerLayer = AVPlayerLayer()

    let topGradientLayer: CAGradientLayer = {
        let gradient = CAGradientLayer()
        gradient.colors = [
            UIColor.black.withAlphaComponent(0.7).cgColor,
            UIColor.clear.cgColor
        ]
        gradient.locations = [0, 1]
        return gradient
    }()

    let bottomGradientLayer: CAGradientLayer = {
        let gradient = CAGradientLayer()
        gradient.colors = [
            UIColor.clear.cgColor,
            UIColor.black.withAlphaComponent(0.8).cgColor
        ]
        gradient.locations = [0, 1]
        return gradient
    }()

    /// Covers the empty player layer in audio-only mode. Added before the
    /// gradients so their sublayers stay on top and the controls stay legible.
    let audioPlaceholderView = UIView()

    // MARK: - Controls

    let controlsView = UIView()
    let spinner = UIActivityIndicatorView(
        style: .whiteLarge
    )
    let settingsButton = UIButton(type: .system)
    let pipButton = UIButton(type: .system)
    let ccButton = UIButton(type: .system)
    let speedButton = UIButton(type: .system)
    let audioOnlyButton = UIButton(type: .system)
    let loopButton = UIButton(type: .system)

    /// Repeat the current video instead of ending it. Per video, not per
    /// app: `resetVideoState()` clears it whenever another video loads.
    var isLooping = false {
        didSet {
            updateLoopButton()
        }
    }

    var pipController: AVPictureInPictureController?
    let rewindButton = UIButton(type: .system)
    let playPauseButton = UIButton(type: .system)
    let forwardButton = UIButton(type: .system)
    let seekBar = VideoSeekBar()
    let currentTimeLabel = UILabel()
    let durationLabel = UILabel()
    let fullscreenButton = UIButton(type: .system)

    // MARK: - Dim Overlay

    let dimView: UIView = {
        let overlay = UIView()
        overlay.backgroundColor = .black
        overlay.alpha = 0.38
        overlay.translatesAutoresizingMaskIntoConstraints = false
        overlay.isUserInteractionEnabled = false
        return overlay
    }()

    // MARK: - SponsorBlock

    var sponsorSegments: [SponsorBlockSegment] = []

    let skipButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(
            ofSize: 14,
            weight: .semibold
        )
        button.backgroundColor = UIColor.black
            .withAlphaComponent(0.75)
        button.layer.borderColor = UIColor.white
            .withAlphaComponent(0.8).cgColor
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 4
        button.contentEdgeInsets = UIEdgeInsets(
            top: 7,
            left: 14,
            bottom: 7,
            right: 14
        )
        button.isHidden = true
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()

    // MARK: - Subtitles

    let subtitleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(
            ofSize: 16, weight: .semibold
        )
        label.numberOfLines = 0
        label.textAlignment = .center
        label.backgroundColor = UIColor.black
            .withAlphaComponent(0.6)
        label.layer.cornerRadius = 4
        label.layer.masksToBounds = true
        label.isHidden = true
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    var subtitleCues: [SubtitleCue] = []
    var onCCTapped: (() -> Void)?

    // MARK: - Playback Speed

    var playbackSpeed: Float = 1.0 {
        didSet {
            player?.rate = playbackSpeed
            updateSpeedButtonTitle()
        }
    }

    let speedOverlay: UIView = {
        let overlay = UIView()
        overlay.backgroundColor = UIColor.black
            .withAlphaComponent(0.85)
        overlay.layer.cornerRadius = 8
        overlay.layer.masksToBounds = true
        overlay.isHidden = true
        overlay.translatesAutoresizingMaskIntoConstraints = false
        return overlay
    }()

    let speedSlider: UISlider = {
        let slider = UISlider()
        slider.minimumValue = 0.25
        slider.maximumValue = 2.0
        slider.value = 1.0
        slider.minimumTrackTintColor = .white
        slider.maximumTrackTintColor = UIColor.white
            .withAlphaComponent(0.3)
        slider.translatesAutoresizingMaskIntoConstraints = false
        return slider
    }()

    let speedLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.monospacedDigitSystemFont(
            ofSize: 14,
            weight: .semibold
        )
        label.textAlignment = .center
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    // MARK: - Zoom

    /// Video scale relative to aspect-fit; 1 = fit, `fillZoom` = no bars.
    var videoZoom: CGFloat = 1
    var pinchStartZoom: CGFloat = 1
    /// True while the current zoom came from auto zoom-to-fill,
    /// not a user pinch — auto re-fit may override it.
    var zoomIsAuto = false
    var readyObservation: NSKeyValueObservation?

    // MARK: - HUD (zoom % and accelerating-seek offset share one overlay)

    var hudWorkItem: DispatchWorkItem?

    let hudLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.monospacedDigitSystemFont(ofSize: 14, weight: .semibold)
        label.textAlignment = .center
        label.backgroundColor = UIColor.black.withAlphaComponent(0.75)
        label.layer.cornerRadius = 4
        label.layer.masksToBounds = true
        label.alpha = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()

    /// Consecutive same-direction taps within `seekBurstWindow` accumulate
    /// into a growing step (issue: flat 10s felt painful on long videos).
    let seekBurst = SeekBurstState()

    /// Press-and-drag scrubbing started anywhere on the picture (#116).
    let holdScrub = HoldScrubState()

    // MARK: - State

    var timeObserver: Any?
    var hideWorkItem: DispatchWorkItem?, bufferingIndicatorWork: DispatchWorkItem?
    var controlsVisible = false
    var wasPlayingOnResign = false, pipStartPending = false
    let multitaskPause = MultitaskPauseState()
    var pipIsStarting = false, playerNeedsRebuildForPiP = false, pipIsRestoring = false
    var duration: Double = 0
    var rateObservation: NSKeyValueObservation?
    var statusObservation: NSKeyValueObservation?
    var timeControlObservation: NSKeyValueObservation?

    /// A mid-playback rebuffer can leave the player clock behind the
    /// rendered media on older devices, so subtitles keyed to `currentTime`
    /// lag until a seek realigns the timebase (#14).
    let clockResync = ClockResyncState()

    override var safeAreaInsets: UIEdgeInsets {
        if isFullscreen && !transform.isIdentity {
            return .zero
        }
        return super.safeAreaInsets
    }

    // MARK: - Init

    override init(frame: CGRect) {
        super.init(frame: frame)
        performSetup()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        performSetup()
    }
}
